Step 1: Extract all file inside Zip archive:
Step 2: create database named rays which can be accessed by username and password root.
Step 3:Go inside folder and run users.sql on mysql database to activate users.
Step 4 import project in STS as  update maven project and deploy.

Following these steps should be sufficient to run the project. 

Implementation check 
1:Goto new registration and create schedule choose future date at first .
2:Navigate through all choices and you will get the reservation successfull page.

3:Now you can check history of reservation for  a user.


 