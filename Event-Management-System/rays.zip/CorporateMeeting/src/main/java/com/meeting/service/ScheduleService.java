package com.meeting.service;

public interface ScheduleService {
	

}
