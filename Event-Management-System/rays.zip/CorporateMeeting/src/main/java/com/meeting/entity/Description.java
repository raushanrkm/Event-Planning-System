package com.meeting.entity;

public class Description {

	
	
}
