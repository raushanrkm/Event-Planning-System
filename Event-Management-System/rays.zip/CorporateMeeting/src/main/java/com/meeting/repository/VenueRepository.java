package com.meeting.repository;

import org.springframework.data.repository.CrudRepository;

import com.meeting.entity.Venue;

public interface VenueRepository extends CrudRepository<Venue, Long> {

	
	
	
}
