package com.meeting.service;

public interface AddressService {

}
